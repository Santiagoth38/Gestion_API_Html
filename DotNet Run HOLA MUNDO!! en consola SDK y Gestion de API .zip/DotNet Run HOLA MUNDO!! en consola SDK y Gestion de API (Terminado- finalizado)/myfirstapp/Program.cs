﻿// See https://aka.ms/new-console-template for more information



for (int i=1; i<=3; i ++){



 Console.WriteLine("Hello, World! My Name is Santiagoth ");
}

for (int i=1; i<=3; i ++){

    Console.WriteLine("Hello, World! My Name is Santiagoth "+i);
}




